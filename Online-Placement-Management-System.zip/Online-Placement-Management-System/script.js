const jobs = [
  {id:1, title:"Java Developer", company:"TechNova Solutions", initials:"TN", color:"#eeeaff", ink:"#6655d8", type:"Full-time", location:"Pune, India", salary:"₹3–5 LPA", skills:"Java · SQL · OOP"},
  {id:2, title:"Frontend Developer", company:"PixelCraft Studio", initials:"PC", color:"#e3f5ff", ink:"#2187b5", type:"Full-time", location:"Hybrid", salary:"₹3–4.5 LPA", skills:"HTML · CSS · JavaScript"},
  {id:3, title:"Web Development Intern", company:"BrightPath Labs", initials:"BP", color:"#e4f8ed", ink:"#249461", type:"Internship", location:"Remote", salary:"₹10k–15k/mo", skills:"HTML · CSS · JS"},
  {id:4, title:"Python Developer Intern", company:"DataSpring", initials:"DS", color:"#fff0df", ink:"#ce7a28", type:"Internship", location:"Mumbai, India", salary:"₹12k/mo", skills:"Python · SQL · Git"},
  {id:5, title:"Software Engineer Trainee", company:"Vertex Digital", initials:"VD", color:"#ffe9ef", ink:"#c34f76", type:"Full-time", location:"Nashik, India", salary:"₹3.5–5 LPA", skills:"Java · DBMS · Git"},
  {id:6, title:"UI Developer", company:"CloudBridge Tech", initials:"CB", color:"#e9efff", ink:"#4d6fc8", type:"Full-time", location:"Remote", salary:"₹3–4 LPA", skills:"HTML · CSS · Figma"}
];

const storageKey = "campusconnect_applications";
let applications = JSON.parse(localStorage.getItem(storageKey) || "[]");

function renderJobs() {
  const search = document.getElementById("searchInput").value.trim().toLowerCase();
  const type = document.getElementById("typeFilter").value;
  const filtered = jobs.filter(job =>
    (job.title.toLowerCase().includes(search) || job.company.toLowerCase().includes(search) || job.skills.toLowerCase().includes(search)) &&
    (type === "All" || job.type === type)
  );
  document.getElementById("jobCount").textContent = filtered.length;
  document.getElementById("emptyState").hidden = filtered.length !== 0;
  document.getElementById("jobGrid").innerHTML = filtered.map(job => {
    const applied = applications.some(app => app.id === job.id);
    return `<article class="job-card">
      <div class="job-top"><div class="company-logo" style="background:${job.color};color:${job.ink}">${job.initials}</div><span class="job-type">${job.type}</span></div>
      <h3>${job.title}</h3><p class="company-name">${job.company}</p>
      <div class="job-meta"><span>⌖ ${job.location}</span><span>${job.skills}</span></div>
      <div class="job-bottom"><div class="salary">${job.salary}<small>Expected compensation</small></div>
      <button class="apply-btn" data-job-id="${job.id}" ${applied ? "disabled" : ""}>${applied ? "Applied ✓" : "Apply now →"}</button></div>
    </article>`;
  }).join("");
}

function renderApplications() {
  document.getElementById("appliedCount").textContent = applications.length;
  const rows = document.getElementById("applicationRows");
  if (!applications.length) {
    rows.innerHTML = '<tr class="empty-row"><td colspan="4">You haven\\'t applied to any jobs yet.</td></tr>';
    return;
  }
  rows.innerHTML = applications.map(app => `<tr>
    <td><strong>${app.title}</strong></td><td>${app.company}</td><td>${app.date}</td><td><span class="status">Application submitted</span></td>
  </tr>`).join("");
}

function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2500);
}

document.getElementById("jobGrid").addEventListener("click", event => {
  const button = event.target.closest("[data-job-id]");
  if (!button || button.disabled) return;
  const job = jobs.find(item => item.id === Number(button.dataset.jobId));
  if (!job) return;
  applications.push({...job, date: new Date().toLocaleDateString("en-IN")});
  localStorage.setItem(storageKey, JSON.stringify(applications));
  renderJobs();
  renderApplications();
  showToast(`Application submitted for ${job.title}!`);
});

document.getElementById("searchInput").addEventListener("input", renderJobs);
document.getElementById("typeFilter").addEventListener("change", renderJobs);
renderJobs();
renderApplications();
