# Online Placement Management System

A responsive student placement portal built using HTML, CSS, and JavaScript. This is a front-end demo project suitable for MCA practice and a beginner portfolio.

## Features
- Student dashboard with job and application statistics
- Job listings with company, role, job type, location, salary, and skills
- Search by job title, company, or skills
- Filter jobs by Full-time or Internship
- Apply to a job and view submitted applications
- Application data stored in browser localStorage
- Responsive layout for desktop and mobile screens

## Technologies Used
- HTML5
- CSS3
- JavaScript
- Browser localStorage

## How to Run
1. Download or clone this repository.
2. Open `index.html` in a web browser.
3. Search jobs and click **Apply now** to test the application flow.

## Important Note
This is a front-end demonstration project. It does not include a backend, database, real student login, or real company job feed. Job listings are sample data. Do not describe it as a production-ready placement system.

## Suggested Future Improvements
- Add a backend using Java/Spring Boot or Node.js
- Connect a MySQL database
- Add secure student/admin authentication
- Create an admin panel to manage job postings
- Add resume upload and application status updates

## Author
MCA Student Project
